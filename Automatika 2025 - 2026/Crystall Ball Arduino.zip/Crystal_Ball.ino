#include <LiquidCrystal.h>
LiquidCrystal lcd(12, 11, 5, 4, 3, 2) ;

const int switchPin = 6;
int switchState = 0;
int prevSwitchState = 0; 
int reply;

void setup() {

  lcd.begin(16, 2) ;
  pinMode(switchPin, INPUT);
  lcd.print("Pitajte");

  lcd.setCursor(0, 1) ;
  lcd.print("Kristalnu kuglu");

}

void loop() {

  switchState = digitalRead(switchPin);
  if (switchState == LOW) {
    reply = random(8);

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Kristalna kugla kaze:");
    lcd.setCursor(0, 1);

    switch(reply) {
      
      case 0:
      lcd.print("Da");
      break;
      case 1:
      lcd.print("Vjerovatno");
      break;
      case 2:
      lcd.print("Djelomicno");
      break;
      case 3:
      lcd.print("Djelomicno");
      break;
      case 4:
      lcd.print("Nesiguran");
      break;
      case 5:
      lcd.print("Pitaj ponovo");
      break;
      case 6:
      lcd.print("Sumnjivo");
      break;
      case 7:
      lcd.print("Ne");
      break;

    }

   }

 }



   

